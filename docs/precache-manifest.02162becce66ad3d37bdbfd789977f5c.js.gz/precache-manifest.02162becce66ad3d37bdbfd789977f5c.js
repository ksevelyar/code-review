self.__precacheManifest = [
  {
    "revision": "48d73e8b65a888e5df4f",
    "url": "/code-review/css/app.0d1dcc8d.css"
  },
  {
    "revision": "48d73e8b65a888e5df4f",
    "url": "/code-review/js/app.6f4db56b.js"
  },
  {
    "revision": "ca236a6bebd087ae0f90",
    "url": "/code-review/js/chunk-vendors.09ef6137.js"
  },
  {
    "revision": "9bd2c1e5d8fbf6216d81e036b0dce2a2",
    "url": "/code-review/index.html"
  },
  {
    "revision": "b6216d61c03e6ce0c9aea6ca7808f7ca",
    "url": "/code-review/robots.txt"
  }
];