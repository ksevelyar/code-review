self.__precacheManifest = [
  {
    "revision": "8302a74ab5f1bcc03af4",
    "url": "/code-review/css/app.c23b35fa.css"
  },
  {
    "revision": "8302a74ab5f1bcc03af4",
    "url": "/code-review/js/app.e963d3df.js"
  },
  {
    "revision": "88fb5e81e5ae4b0655d2",
    "url": "/code-review/js/chunk-vendors.def87c77.js"
  },
  {
    "revision": "62ae5c245c8dd465fb3c49aff1c54a44",
    "url": "/code-review/index.html"
  },
  {
    "revision": "b6216d61c03e6ce0c9aea6ca7808f7ca",
    "url": "/code-review/robots.txt"
  }
];