self.__precacheManifest = [
  {
    "revision": "b5c8230d8c7080ba6e9e",
    "url": "/code-review/css/app.d2ba7734.css"
  },
  {
    "revision": "b5c8230d8c7080ba6e9e",
    "url": "/code-review/js/app.558f5050.js"
  },
  {
    "revision": "ca236a6bebd087ae0f90",
    "url": "/code-review/js/chunk-vendors.09ef6137.js"
  },
  {
    "revision": "9873878aff020575ac7c5363fb8e6c48",
    "url": "/code-review/index.html"
  },
  {
    "revision": "b6216d61c03e6ce0c9aea6ca7808f7ca",
    "url": "/code-review/robots.txt"
  }
];