self.__precacheManifest = [
  {
    "revision": "10e689cb690e18a0359f",
    "url": "/code-review/css/app.e2cb7bcd.css"
  },
  {
    "revision": "10e689cb690e18a0359f",
    "url": "/code-review/js/app.d2b5b541.js"
  },
  {
    "revision": "ca236a6bebd087ae0f90",
    "url": "/code-review/js/chunk-vendors.09ef6137.js"
  },
  {
    "revision": "0fdd5ee3933f53fb4d6de47d0d3b9333",
    "url": "/code-review/index.html"
  },
  {
    "revision": "b6216d61c03e6ce0c9aea6ca7808f7ca",
    "url": "/code-review/robots.txt"
  }
];