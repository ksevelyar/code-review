self.__precacheManifest = [
  {
    "revision": "c04c75799f6db4a12f44",
    "url": "/code-review/css/app.155fc6a7.css"
  },
  {
    "revision": "c04c75799f6db4a12f44",
    "url": "/code-review/js/app.fb9d5f5b.js"
  },
  {
    "revision": "ca236a6bebd087ae0f90",
    "url": "/code-review/js/chunk-vendors.09ef6137.js"
  },
  {
    "revision": "adb018cb2fcd83fae221bca72a9c475b",
    "url": "/code-review/index.html"
  },
  {
    "revision": "b6216d61c03e6ce0c9aea6ca7808f7ca",
    "url": "/code-review/robots.txt"
  }
];