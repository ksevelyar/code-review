self.__precacheManifest = [
  {
    "revision": "4fd141ba212634496fc4",
    "url": "/code-review/css/app.d187116f.css"
  },
  {
    "revision": "4fd141ba212634496fc4",
    "url": "/code-review/js/app.bbe4ca7d.js"
  },
  {
    "revision": "25144b0c053b524c10d1",
    "url": "/code-review/js/chunk-vendors.75b959c4.js"
  },
  {
    "revision": "d85afa8e091c2342488f46b34743078e",
    "url": "/code-review/index.html"
  },
  {
    "revision": "b6216d61c03e6ce0c9aea6ca7808f7ca",
    "url": "/code-review/robots.txt"
  }
];